#include <Arduino.h>
#include <EloquentTinyML.h>
#include "model_data.h"
#include "DHT.h"

#define DHTTYPE DHT22

const uint8_t dhtPins[]  = {15, 16, 17, 13}; 
const uint8_t pm25Pins[] = {34, 32, 25, 27}; // N, W, E, S PM2.5 Pins
const uint8_t coPins[]   = {35, 33, 26, 14}; // N, W, E, S CO Pins

const char* locationNames[] = {
  "Campus Node (North)",
  "Campus Node (West)",
  "Campus Node (East)",
  "Campus Node (South)"
};

DHT dht[] = {
  {dhtPins[0], DHTTYPE},
  {dhtPins[1], DHTTYPE},
  {dhtPins[2], DHTTYPE},
  {dhtPins[3], DHTTYPE}
};

#define N_INPUTS 4
#define N_OUTPUTS 1
#define TENSOR_ARENA_SIZE 4 * 1024 

Eloquent::TinyML::TfLite<N_INPUTS, N_OUTPUTS, TENSOR_ARENA_SIZE> ml;

void setup() {
  Serial.begin(115200);
  delay(1500); 

  for (int i = 0; i < 4; i++) {
    dht[i].begin();
  }

  if (!ml.begin(comfort_model)) { 
    while (1) { delay(1000); }
  }
}

void loop() {
  int currentPM25[4];
  int currentCO[4];

  // STEP 1: Scan gas nodes
  for (int i = 0; i < 4; i++) {
    currentPM25[i] = analogRead(pm25Pins[i]);
    currentCO[i]   = analogRead(coPins[i]);
  }

  // STEP 2: Process nodes independently across the diamond layout
  for (int i = 0; i < 4; i++) {
    float temp = dht[i].readTemperature();
    float humid = dht[i].readHumidity();

    if (isnan(temp) || isnan(humid)) {
      continue; 
    }

    float gasPM25 = (float)currentPM25[i];
    float gasCO   = (float)currentCO[i];

    // Normalization
    float scaledPM25 = gasPM25 / 4095.0;
    float scaledCO   = gasCO / 4095.0;
    float scaledTemp = (temp - (-10.0)) / (45.0 - (-10.0));
    float scaledHumidity = (humid - 0.0) / (100.0 - 0.0);

    float inputFeatures[4] = {scaledPM25, scaledCO, scaledTemp, scaledHumidity};
    float comfortScore = ml.predict(inputFeatures);

    bool isPM25Alert = (gasPM25 > 2200.0);
    bool isCOAlert   = (gasCO > 2200.0);
    bool isHotAlert  = (temp > 33.0);
    bool isColdAlert = (temp < 15.0);

    Serial.print(locationNames[i]); Serial.print(" | ");
    Serial.print("PM2.5: "); Serial.print((int)gasPM25); Serial.print(" | ");
    Serial.print("CO: "); Serial.print((int)gasCO); Serial.print(" | ");
    Serial.print("Temp: "); Serial.print(temp, 1); Serial.print("C | ");
    Serial.print("Humid: "); Serial.print(humid, 1); Serial.print("% | ");
    Serial.print("STATUS: ");

    if (comfortScore > 0.8 || isPM25Alert || isCOAlert || isHotAlert || isColdAlert) {
      Serial.println("POOR");
    } else {
      Serial.println("GOOD");
    }
  }

  // =========================================================================
  // STEP 3: FIXED & ACCURATE DIRECTIONAL TRACER LOGIC
  // =========================================================================
  Serial.print("POLLUTION DIRECTION TRACER: ");
  
  // Set the activation threshold. If a sensor is below 400, we consider it clean air.
  const int SPIKE_THRESHOLD = 400; 

  int maxPM25Val = SPIKE_THRESHOLD; 
  int maxCOVal = SPIKE_THRESHOLD;   
  
  int maxPM25Idx = -1;
  int maxCOIdx = -1;
  
  const char* cardNames[] = {"NORTH", "WEST", "EAST", "SOUTH"};

  // Find the absolute peak source only if it breaks past the clean air baseline threshold
  for (int i = 0; i < 4; i++) {
    if (currentPM25[i] > maxPM25Val) { 
      maxPM25Val = currentPM25[i]; 
      maxPM25Idx = i; 
    }
    if (currentCO[i] > maxCOVal) { 
      maxCOVal = currentCO[i]; 
      maxCOIdx = i; 
    }
  }

  // Print tracking messages dynamically based on actual pollution events
  if (maxPM25Idx != -1 && maxCOIdx != -1) {
    Serial.print("[PM2.5 source from "); Serial.print(cardNames[maxPM25Idx]);
    Serial.print("] & [CO source from "); Serial.print(cardNames[maxCOIdx]); Serial.println("]");
  } 
  else if (maxPM25Idx != -1) {
    Serial.print("[PM2.5 source from "); Serial.print(cardNames[maxPM25Idx]); Serial.println("] & [CO source from NONE]");
  } 
  else if (maxCOIdx != -1) {
    Serial.print("[PM2.5 source from NONE] & [CO source from "); Serial.print(cardNames[maxCOIdx]); Serial.println("]");
  } 
  else {
    Serial.println("ENVIRONMENT STABLE (ALL NODES CLEAN)");
  }

  Serial.println("--------------------------------------------------------------------------------");
  delay(3000); 
}